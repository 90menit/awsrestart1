myString = "This is a string."
print(myString)
print("====================")
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
print("====================")
satu = "water"
dua = " fall"
tiga = satu + dua
print(tiga)
print("====================")
name = input("What is your name? ")
print("hi " + name)

color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))