import array as arr

myArr = arr.array('i', [1,2,3])
print(type(myArr))

# list
print('\rmyFruitList:')
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))

print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

(myFruitList[0]) = "Duren"
(myFruitList[1]) = "Nangka"
(myFruitList[2]) = "MusangKing"

print(myFruitList)

print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

# 2d list

group = [ 
    ["ari", "ara", "ana"],
    ["bara","bari", "bana"]
    ]
#print semua grup yang ada di line 2
print(group[1])
#print yang ada di line 2 urutan ke 3
print(group[1][2])

# Tuple

Tuple = ("apple", "banana", "pineapple")
print(Tuple)
print(type(Tuple))

print(Tuple[0])
print(Tuple[1])
print(Tuple[2])
for item in Tuple:
    print(f"{item} is of the data type {type(item)}")

# Dictionary

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}

print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])

# kalau list pake ( ) kalau tuple pake [ ] kalau dictionary pake { }