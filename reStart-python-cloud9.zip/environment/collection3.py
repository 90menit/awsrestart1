
#list
print("list")
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
# index mulai dari 0 sebelah kiri, kalo minus mulai dari kanan ngitung nya
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[-2])
(myFruitList[2]) = "MusangKing" #buat replace index
print(myFruitList)
print("===============================================")

#tuple
print("tuple")
myFruitList = ("apple", "banana", "cherry")
print(myFruitList)
print(type(myFruitList))
# index mulai dari 0 sebelah kiri, kalo minus mulai dari kanan ngitung nya
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[-2])
print(myFruitList)
print("===============================================")

#SET
print("SET")
sett = {"apple", "banana", "cherry", "banana", "cherry"}
print(sett)
print(type(sett))
print("===============================================")


# Dictionary
print("Dictionary")
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])
